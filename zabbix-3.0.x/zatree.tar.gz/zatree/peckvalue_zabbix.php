<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">   
        <title>时间列表流量峰值</title>
        <script type="text/javascript" src="static/jquery-2.0.3.min.js"></script>
        <script language="javascript" type="text/javascript" src="My97DatePicker/WdatePicker.js"></script>
        <script type="text/javascript" src="static/jquery.fancybox.min.js"></script>
        <style type="text/css">
	table.gridtable {
		font-family: verdana,arial,sans-serif;
		font-size:11px;
		color:#333333;
		border-width: 1px;
		border-color: #666666;
		border-collapse: collapse;
		}
		table.gridtable th {
		border-width: 1px;
		padding: 8px;
		border-style: solid;
		border-color: #666666;
		background-color: #dedede;
		}
		table.gridtable td {
		border-width: 1px;
		padding: 8px;
		border-style: solid;
		border-color: #666666;
		background-color: #ffffff;
	}
	</style>
        <script type="text/javascript">
         
                function changeTongjiType() {
                    var tongjitpye = $("select[name='tongjitpye']").val();
                    var tongjitpye = $("select[name='tongjitype_select']").val();
                    if (tongjitpye === '' || typeof(tongjitpye) === 'undefined') {
                      $("select[name='tongjitype_select']").val('month');
		              $("#changeType").val('month');
                      $("#search_month_div").hide();
                    } else if(tongjitpye=="month"){
                      $("select[name='tongjitype_select']").val(tongjitpye);
		              $("#changeType").val(tongjitpye);
                      $("#search_month_div").hide();
                    }else{
                      $("select[name='tongjitype_select']").val(tongjitpye);
		              $("#changeType").val(tongjitpye);
                      $("#search_month_div").show();
                    }
                }


                function changeSelectMonth() {
                    var search_month = $("select[name='search_month']").val();
                            if (search_month === '' || typeof(search_month) === 'undefined') {
                    $("select[name='search_month']").val(1);
                    } else {
                    $("select[name='search_month']").val(search_month);
                    }
                }
                
                function onCheckSubmit() {
                    $("#searchForm").attr("action", 'peckvalue_zabbix.php');
                    $("#searchForm").submit();
               }
                
                
                
        </script>
        <link href="static/page.css" rel="stylesheet" type="text/css"/>
    </head>
    <body style="text-align:center;" >

        <?php
        date_default_timezone_set('PRC');
        include_once("page.class.php");
        include_once("zabbix_config.php");
        include_once("ZabbixApi.class.php");
        include_once("peck_value_ajax.php");
        include_once dirname(dirname(__FILE__)) . '/include/items.inc.php';
        $tongjitype = (isset($_REQUEST["tongjitype"]) && $_REQUEST["tongjitype"] ) ? $_REQUEST["tongjitype"] : 'month';
        $hostid = (isset($_REQUEST["hostid"]) && $_REQUEST["hostid"] > 0) ? $_REQUEST["hostid"] : ''; //主机id
        $group_class = (isset($_REQUEST["group_class"]) && $_REQUEST["group_class"] != '') ? $_REQUEST["group_class"] : ''; //分组
        $search_month = (isset($_REQUEST["search_month"]) && $_REQUEST["search_month"] > 0) ? $_REQUEST["search_month"] : 1;
        $year=date("Y");
        global $zabbix_api_config;

        $url_api_config=get_url_config();
        $url_http=$url_api_config['url'];
        $zabbixApi = new ZabbixApi($url_http . '/' . trim($zabbix_api_config['api_url']), trim($url_api_config['user']), trim($url_api_config['password']));

        $items_list = array();
        $graph_search_list = array();
        $graphids = array();
        if ($hostid > 0) {
            //根据分组Id找所有的host
            $graphs = $zabbixApi->graphGet(array("hostids" => array($hostid), "output" => "extend", "sortfield" => "name"));
            foreach ($graphs as &$each) {
                $graphids[] = $each->graphid;
                $graphid = $each->graphid;
                $graphname = $each->name;
                $graph_search_list[$graphid] = $graphname;
            }
        } else {
            //查询分组里面的所有机器
            $host_ids = array();
            $hosts = $zabbixApi->hostGet(array("output" => "extend", "monitored_hosts" => true, "groupids" => array($group_class)));
            foreach ($hosts as $each_host) {
                $host_ids[] = $each_host->hostid;
            }
            //查询分组下的所有机器的所有图形
            $graphs = $zabbixApi->graphGet(array("hostids" => $host_ids, "output" => "extend", "sortfield" => "name"));
            foreach ($graphs as &$each) {
                $graphids[] = $each->graphid;
                $graphid = $each->graphid;
                $graphname = $each->name;
                $graph_search_list[$graphid] = $graphname;
            }
        }

        // print_r($graphids);
        //根据graphid获取itemid
        //查询所有的graphitem
		$itemid_list_info=array();
		$items_list_graph = $zabbixApi->graphitemGet(array("graphids" => array_keys($graph_search_list), "output" => "extend","expandData"=>1));
		
		
		//因为数据量大嵌套循环
		$id_size=200;
		$id_pnum = ceil(count($items_list_graph) / $id_size);  //总页数，ceil()函数用于求大于数字的最小整数
		for($id_page=1;$id_page<=$id_pnum;$id_page++){
				$newarr = array_slice($items_list_graph, ($id_page-1)*$id_size, $id_size);
				foreach($newarr as $each_item){
				   $itemid_list_info[$each_item->itemid]=array('item_id'=>$each_item->itemid,'graph_item_info'=>(array)$each_item);
				}
				
		}
		
		//查询所有的item信息
		$items_list_info = $zabbixApi->itemGet(array("itemids" => array_keys($itemid_list_info), "output" => "extend"));
		
		
		//将两个数组合并为一个数组  分页循环
		$item_size=200;
		$item_pnum = ceil(count($items_list_info) / $item_size);  //总页数，ceil()函数用于求大于数字的最小整数
		$items_list=array();
		for($item_page=1;$item_page<=$item_pnum;$item_page++){
				$newarr = array_slice($items_list_info, ($item_page-1)*$item_size, $item_size);
				foreach($newarr as $each_items){
					$items_list[]=array_merge($itemid_list_info[$each_items->itemid]['graph_item_info'],(array)$each_items);
				}
				
		}
		
		
		//获取格式化后的item数据
		$width = 200;
		$get_max_format_value = array();
		$time_list = gettimelist($tongjitype, $search_month);

		$size=200;//每次查询20条
		$pnum = ceil(count($items_list) / $size);  //总页数，ceil()函数用于求大于数字的最小整数
		//用array_slice(array,offset,length) 函数在数组中根据条件取出一段值;array(数组),offset(元素的开始位置),length(组的长度)

		$page_result=array();

		 foreach ($time_list as $each_time) {
		 
			for($page=1;$page<=$pnum;$page++){
				$newarr = array_slice($items_list, ($page-1)*$size, $size);
                                $str_begin_time=date("Ymd",strtotime($each_time['begin']))."000000";

				$list = array('list_item' => $newarr, 'parame' => array('stime' => $str_begin_time, 'period' => $each_time['period'], 'sizeX' => $width));
				$format_list = $zabbixApi->getItemMaxFormat($list, '');
						
				$format_list = (array) $format_list;
				foreach ($format_list as &$format) {
					$format = (array) $format;
					if (is_array($format)) {
						foreach ($format as $key_obj => &$value_obj) {
							if (is_object($value_obj)) {
								$value_obj = (array) $value_obj;
							}
						}
					}
				}
				$order_list_result = (array) $format_list; 

				$page_result[]=$order_list_result;
			}
			  
			$get_max_format_value[date("Y-m-d", strtotime($each_time['begin']))] = array_values($page_result);
		   
		}



		$return_list = array();
		$day_list = array();
		foreach ($get_max_format_value as $day => $day_value) {
			$day_value = array_values($day_value);
			foreach ($day_value as $graphid => $graph_info) {
				foreach ($graph_info as $itemname => $item_info_l) {
					//print_r($item_info);
				   if(count($item_info_l)){
					 foreach($item_info_l as $each_item =>$item_info){
					   $graphid=$item_info["graphid"];
					   $itemname=$item_info["itemname"];
					   $graph_name = $item_info['hostname'] . ":" . $graph_search_list[$graphid];
					   $day_list[$day][$graph_name][$itemname] = $item_info['max_format'];
					   $return_list[$graph_name][$itemname][$day] =array('max'=> $item_info['max_format'],'min'=> $item_info['min_format'],'avg'=> $item_info['avg_format']);
					 }
				   }
				}
			}
		}


		
        ?>
        <form method="get" style="font-size:8px;text-align:left;padding-left:10px;" id="searchForm" >
            <div>
                <input type="hidden" name="hostid" value="<?php echo $hostid; ?>" id="hostid" />
                <input type="hidden" name="group_class" value="<?php echo $group_class; ?>" id="group_class" />
                <input type="hidden" name="tongjitype" value="<?php echo $tongjitype; ?>" id="changeType" />
                <div id="tongji_type_div" style="width:120px; height:20px;float:left;">
                统计类型:<select id="tongjitype_select" name="tongjitype_select" onChange="changeTongjiType();" >
                    <option value="month" <?php
                    if ($tongjitype == 'month') {
                        echo 'selected="selected"';
                    };
                    ?>>月峰值</option>
                    <option value="week" <?php
                    if ($tongjitype == 'week') {
                        echo 'selected="selected"';
                    };
                    ?>>周峰值</option>
                    <option value="days" <?php
                    if ($tongjitype == 'days') {
                        echo 'selected="selected"';
                    };
                    ?>>日峰值</option>
                </select>
                </div>
                <div id="search_month_div" style="padding-left:20px;width:150px; height:20px;float:left;<?php if($tongjitype == 'month'){ ?>display:none; <?php } ?>" ><span>月份:</span>
                <select id="search_month" name="search_month"  onchange="changeSelectMonth();">
                    <?php
                    for ($i = 1; $i <= 12; $i++) {
                        if ($i == $search_month) {
                            echo "<option value='$i' selected='selected'>" . $i . "月</option>";
                        } else {
                            echo "<option value='$i'>" . $i . "月</option>";
                        }
                    }
                    ?>
                </select>
                </div>


                <input type="button" value="搜索" onClick="onCheckSubmit();"/>
            </div> 
        </form>
    <div style="padding-top:10px;" >  

<?php if ($group_class!='' || $hostid!=''){ ?>
      <table width="725" height="138" class="gridtable">
        <tr>
          <th colspan="3" >项目</th>
          <?php if(in_array($tongjitype,array("month","days"))){ ?>
          <?php  foreach(array_keys($day_list) as $key=>$day_value){ ?>
          <?php if($tongjitype=="month"){ 
              $day_str=  explode("-", $day_value);
          ?>
          <th width="111"><?php echo $year."年".intval($day_str[1])."月"; ?></th>
          <?php }elseif($tongjitype=="days"){ 
              $day_str=  explode("-", $day_value);
          ?>
          <th width="81"><?php echo $year."年".$search_month."月".intval($day_str[2])."日"; ?></th>
          <?php } ?>
          <?php } ?>
          <?php }else{ ?>
             <?php foreach($time_list as $key=>$each_time_info){?>
          <th width="136"><?php echo date("Y-m-d",  strtotime($each_time_info['begin']))."到".date("Y-m-d",  strtotime($each_time_info['end'])) ;?></th> 
             <?php } ?>
          <?php }  ?>
        </tr>
        <?php  $i=1; foreach($return_list as $host_name=>$each_graph){ $i=1;    ?>
        <?php   foreach($each_graph as $item_name=>$day_graph_value){ ?>
        
          <?php    if($i==1){ $i=2; ?>  
		   
          <td width="148" rowspan="<?php $count=3*count($each_graph); echo $count; ?>"><?php echo $host_name; ?></td><td width="86" rowspan="3"><?php echo $item_name;?></td> 
           
          <?php }else{  ?>  
                  <tr><td width="86" rowspan="3"><?php echo $item_name;?></td>
          <?php }?>
		  
              <td>max</td>
                     <?php foreach($day_graph_value as $key_day=>$max_value){?>
                      <td><?php echo $max_value['max']; ?></td>
                     <?php } ?>
                  </tr>
                <tr>
                  <td>min</td>
                  <?php foreach($day_graph_value as $key_day=>$max_value){?>
                      <td><?php echo $max_value['min']; ?></td>
                  <?php } ?>
                </tr>
                <tr>
                  <td>avg</td>
                  <?php foreach($day_graph_value as $key_day=>$max_value){?>
                     <td><?php echo $max_value['avg']; ?></td>
                  <?php } ?>
                 </tr>

           
        
        <?php } ?>
        <?php } ?>

      </table>

<?php }  ?>

    </div>
      </br>
        <div align="center" style='font-size:12px;'>
            <a href="https://github.com/BillWang139967/zatree" target="_blank">Zatree</a> version 3.0 for Zabbix 3.0.x
        </div> 
        
    </body>
