<?php

global $month_list;
$month_list = array(
    1 => "January ",
    2 => "February",
    3 => "Marcy",
    4 => "April",
    5 => "May",
    6 => "June",
    7 => "July",
    8 => "August",
    9 => "September",
    10 => "October",
    11 => " November",
    12 => "December"
);


function getdaysbymonth($month = 1) {
    $days_31 = array(1, 3, 5, 7, 8, 10, 12);

    //闰年的判断定义能被4整除且又能不能被100整除 是闰年能直接被400整除也是闰年
    if ($month == 2) {
        //判断当前是不是闰年
        $year = date("Y");
        $last = substr($month, -2);
        if ($last == "00") { //是整百的倍数就看能否被400整除
            if ($year % 400 == 0) {
                return 29;
            }
        }
        //看能不能被4整除并且又不能被100整除
        if ($year % 4 == 0 && $year % 100 != 0) {
            return 29;
        }

        return 28;
    }

    if (in_array($month, $days_31)) {
        return 31;
    }

    return 30;
}

function gettimelist($tongjitype = 'month', $month = 1) {
    global $month_list;
    $time_begin_last = " 00:00:00"; //开始时间后缀
    $time_end_last = " 23:59:59"; //结束时间后缀
    $year = date("Y");
    $time_list = array();
    switch ($tongjitype) {
        case "month":
            for ($i = 1; $i <= 12; $i++) {
                $days = getdaysbymonth($i);
                $istr = $i < 10 ? "0" . $i : $i;
                $time_list[] = array("begin" => $year . "-" . $istr . "-01" . $time_begin_last, "end" => $year . "-" . $istr . "-" . $days . $time_end_last, "period" => strtotime($year . "-" . $istr . "-" . $days . $time_end_last) - strtotime($year . "-" . $istr . "-01" . $time_begin_last));
            }
            return $time_list;
            break;
        case "week":
            $days = getdaysbymonth($month);
            $monthstr = $month < 10 ? "0" . $month : $month;
            //先查询当月第一天是周几
            $begin_week = date("w", strtotime($year . "-" . $monthstr . "-" . "01"));
            $last_week = date("w", strtotime($year . "-" . $monthstr . "-" . "$days"));
            $month_en = $month_list[$month];
            $last_monday_date = $last_sunday_date = NUll;
            if ($begin_week == 1) { //当月1号是周一
                $first_monday = $year . "-" . $monthstr . "-" . "01";
                $last_monday_date = $first_monday;
            } else {
                //获取上周一
                $last_monday_date = date("Y-m-d", strtotime("+1 day  1 $month_en  $year  last Sunday"));
                $first_monday = date("Y-m-d", strtotime("+8 day  1 $month_en  $year  last Sunday"));
            };

            if ($last_week == 0) {
                $last_sunday_date = $year . "-" . $monthstr . "-" . $days;
            } else {
                $add_day = 7 - $last_week;
                $last_sunday_date = date("Y-m-d", strtotime("+$add_day day $days $month_en  $year last Sunday"));
            }



            //计算最后一个周末和第一个周一之间有几个周末
            $strchazhi = strtotime($last_sunday_date) - strtotime($last_monday_date);
            $weekcha = ceil($strchazhi / (3600 * 24 * 7));

            for ($i = 1; $i <= $weekcha; $i++) {
                $begin = date("Y-m-d", strtotime($last_monday_date) + ($i - 1) * 3600 * 24 * 7) . $time_begin_last;
                $end = date("Y-m-d", strtotime($begin) + 3600 * 24 * 6) . $time_end_last;
                $time_list[] = array("begin" => $begin, "end" => $end, "period" => strtotime($end) - strtotime($begin));
            }

            return $time_list;

            break;

        default:
            $days = getdaysbymonth($month);
            $monthstr = $month < 10 ? "0" . $month : $month;
            for ($i = 1; $i <= $days; $i++) {
                $istr = $i < 10 ? "0" . $i : $i;
                $time_list[] = array("begin" => $year . "-" . $monthstr . "-" . $istr . $time_begin_last, "end" => $year . "-" . $monthstr . "-" . $istr . $time_end_last, "period" => strtotime($year . "-" . $monthstr . "-" . $istr . $time_end_last) - strtotime($year . "-" . $monthstr . "-" . $istr . $time_begin_last));
            }
            return $time_list;

            break;
    }
}

?>
