<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">   
        <title>时间列表流量峰值</title>
        <script type="text/javascript" src="static/jquery-2.0.3.min.js"></script>
        <script src="echarts/doc/asset/js/esl/esl.js"></script>
		<script src="echarts/doc/example/www/js/echarts.js"></script>
		<script src="echarts/doc/asset/js/jquery.min.js"></script>
        <style type="text/css">
  .bottom   
    {  
        position:fixed;  
         right:0px;   
        _position:absolute;  
         /*_right:17px;*/  
        bottom:0px;  
        background:#f1f1f1;  
        color:black;  
        border-top:1px solid #fff;  
        display:block;  
        width:100%;  
        text-align:center;        
     }

	table.gridtable {
		font-family: verdana,arial,sans-serif;
		font-size:11px;
		color:#333333;
		border-width: 1px;
		border-color: #666666;
		border-collapse: collapse;
		}
		table.gridtable th {
		border-width: 1px;
		padding: 8px;
		border-style: solid;
		border-color: #666666;
		background-color: #dedede;
		}
		table.gridtable td {
		border-width: 1px;
		padding: 8px;
		border-style: solid;
		border-color: #666666;
		background-color: #ffffff;
	}
	</style>
        <script type="text/javascript">
         
                function changeTongjiType() {
                
                    var tongjitpye = $("select[name='tongjitype_select']").val();
                    if (tongjitpye === '' || typeof(tongjitpye) === 'undefined') {
                      $("select[name='tongjitype_select']").val('month');
		      $("#changeType").val('month');
                      //$("select[name='search_month']").attr("style","display:none");
                      $("#search_month_div").hide();
                    } else if(tongjitpye=="month"){
                      $("select[name='tongjitype_select']").val(tongjitpye);
		      $("#changeType").val(tongjitpye);
                      //$("select[name='search_month']").attr("style","display:none");
                      $("#search_month_div").hide();
                    }else{
                      $("select[name='tongjitype_select']").val(tongjitpye);
		      $("#changeType").val(tongjitpye);
                      //$("select[name='search_month']").attr("style","display:block");
                      $("#search_month_div").show();
                    }
                }


                function changeSelectMonth() {
                    var search_month = $("select[name='search_month']").val();
                            if (search_month === '' || typeof(search_month) === 'undefined') {
                    $("select[name='search_month']").val(1);
                    } else {
                    $("select[name='search_month']").val(search_month);
                    }
                }
                
                function onCheckSubmit() {
                    $("#searchForm").attr("action", 'echart_zabbix.php');
                    $("#searchForm").submit();
               }
                
                
                
        </script>
        <link href="static/page.css" rel="stylesheet" type="text/css"/>
    </head>
    <body style="text-align:center;" >
	
	   

        <?php
        date_default_timezone_set('PRC');
        include_once("page.class.php");
        include_once("zabbix_config.php");
        include_once("ZabbixApi.class.php");
        include_once("peck_value_ajax.php");
        include_once dirname(dirname(__FILE__)) . '/include/items.inc.php';
        $tongjitype = (isset($_REQUEST["tongjitype"]) && $_REQUEST["tongjitype"] ) ? $_REQUEST["tongjitype"] : 'month';
        $hostid = (isset($_REQUEST["hostid"]) && $_REQUEST["hostid"] > 0) ? $_REQUEST["hostid"] : ''; //主机id
        $group_class = (isset($_REQUEST["group_class"]) && $_REQUEST["group_class"] != '') ? $_REQUEST["group_class"] : ''; //分组
        $search_month = (isset($_REQUEST["search_month"]) && $_REQUEST["search_month"] > 0) ? $_REQUEST["search_month"] : 1;
        $year=date("Y");
        global $zabbix_api_config;

        $url_api_config=get_url_config();
        $url_http=$url_api_config['url'];
        $zabbixApi = new ZabbixApi($url_http . '/' . trim($zabbix_api_config['api_url']), trim($url_api_config['user']), trim($url_api_config['password']));

        $items_list = array();
        $graph_search_list = array();
        $graphids = array();
        if ($hostid > 0) {
            //根据分组Id找所有的host
            $graphs = $zabbixApi->graphGet(array("hostids" => array($hostid), "output" => "extend", "sortfield" => "name"));
            foreach ($graphs as &$each) {
                $graphids[] = $each->graphid;
                $graphid = $each->graphid;
                $graphname = $each->name;
                $graph_search_list[$graphid] = $graphname;
            }
        } else {
            //查询分组里面的所有机器
            $host_ids = array();
            $hosts = $zabbixApi->hostGet(array("output" => "extend", "monitored_hosts" => true, "groupids" => array($group_class)));
            foreach ($hosts as $each_host) {
                $host_ids[] = $each_host->hostid;
            }
            //查询分组下的所有机器的所有图形
            $graphs = $zabbixApi->graphGet(array("hostids" => $host_ids, "output" => "extend", "sortfield" => "name"));
            foreach ($graphs as &$each) {
                $graphids[] = $each->graphid;
                $graphid = $each->graphid;
                $graphname = $each->name;
                $graph_search_list[$graphid] = $graphname;
            }
        }

        // print_r($graphids);
        //根据graphid获取itemid
        //查询所有的graphitem
		$itemid_list_info=array();
		$items_list_graph = $zabbixApi->graphitemGet(array("graphids" => array_keys($graph_search_list), "output" => "extend","expandData"=>1));
		
		
		//因为数据量大嵌套循环
		$id_size=200;
		$id_pnum = ceil(count($items_list_graph) / $id_size);  //总页数，ceil()函数用于求大于数字的最小整数
		for($id_page=1;$id_page<=$id_pnum;$id_page++){
				$newarr = array_slice($items_list_graph, ($id_page-1)*$id_size, $id_size);
				foreach($newarr as $each_item){
				   $itemid_list_info[$each_item->itemid]=array('item_id'=>$each_item->itemid,'graph_item_info'=>(array)$each_item);
				}
				
		}
		
		//查询所有的item信息
		$items_list_info = $zabbixApi->itemGet(array("itemids" => array_keys($itemid_list_info), "output" => "extend"));
		
		
		//将两个数组合并为一个数组  分页循环
		$item_size=200;
		$item_pnum = ceil(count($items_list_info) / $item_size);  //总页数，ceil()函数用于求大于数字的最小整数
		$items_list=array();
		for($item_page=1;$item_page<=$item_pnum;$item_page++){
				$newarr = array_slice($items_list_info, ($item_page-1)*$item_size, $item_size);
				foreach($newarr as $each_items){
					$items_list[]=array_merge($itemid_list_info[$each_items->itemid]['graph_item_info'],(array)$each_items);
				}
				
		}
		
		
		//获取格式化后的item数据
		$width = 200;
		$get_max_format_value = array();
		$time_list = gettimelist($tongjitype, $search_month);

		$size=200;//每次查询20条
		$pnum = ceil(count($items_list) / $size);  //总页数，ceil()函数用于求大于数字的最小整数
		//用array_slice(array,offset,length) 函数在数组中根据条件取出一段值;array(数组),offset(元素的开始位置),length(组的长度)

		$page_result=array();

		 foreach ($time_list as $each_time) {
		 
			for($page=1;$page<=$pnum;$page++){
				$newarr = array_slice($items_list, ($page-1)*$size, $size);
                                $str_begin_time=date("Ymd",strtotime($each_time['begin']))."000000";

				$list = array('list_item' => $newarr, 'parame' => array('stime' => $str_begin_time, 'period' => $each_time['period'], 'sizeX' => $width));
				$format_list = $zabbixApi->getItemMaxFormat($list, '');
						
				$format_list = (array) $format_list;
				foreach ($format_list as &$format) {
					$format = (array) $format;
					if (is_array($format)) {
						foreach ($format as $key_obj => &$value_obj) {
							if (is_object($value_obj)) {
								$value_obj = (array) $value_obj;
							}
						}
					}
				}
				$order_list_result = (array) $format_list; 

				$page_result[]=$order_list_result;
			}
			  
			$get_max_format_value[date("Y-m-d", strtotime($each_time['begin']))] = array_values($page_result);
		   
		}



		$return_list = array();
		$day_list = array();
		foreach ($get_max_format_value as $day => $day_value) {
			$day_value = array_values($day_value);
			foreach ($day_value as $graphid => $graph_info) {
				foreach ($graph_info as $itemname => $item_info_l) {
					//print_r($item_info);
				   if(count($item_info_l)){
					 foreach($item_info_l as $each_item =>$item_info){
					   $graphid=$item_info["graphid"];
					   $itemname=$item_info["itemname"];
					   $graph_name = $item_info['hostname'] . ":" . $graph_search_list[$graphid];
					   $day_list[$day][$graph_name][$itemname] = $item_info['max_format'];
					   $return_list[$graph_name][$itemname][$day] =array('max'=> $item_info['max_format'],'min'=> $item_info['min_format'],'avg'=> $item_info['avg_format'],"value"=>$item_info['max']);
					 }
				   }
				}
			}
		}

		
        ?>
        <div>
        <form method="get" style="font-size:8px;text-align:left;padding-left:10px;" id="searchForm" >
            <div>
                <input type="hidden" name="hostid" value="<?php echo $hostid; ?>" id="hostid" />
                <input type="hidden" name="group_class" value="<?php echo $group_class; ?>" id="group_class" />
                <input type="hidden" name="tongjitype" value="<?php echo $tongjitype; ?>" id="changeType" />
                <div id="tongji_type_div" style="width:120px; height:20px;float:left;">
                统计类型:<select id="tongjitype_select" name="tongjitype_select" onChange="changeTongjiType();" >
                    <option value="month" <?php
                    if ($tongjitype == 'month') {
                        echo 'selected="selected"';
                    };
                    ?>>月峰值</option>
                    <option value="week" <?php
                    if ($tongjitype == 'week') {
                        echo 'selected="selected"';
                    };
                    ?>>周峰值</option>
                    <option value="days" <?php
                    if ($tongjitype == 'days') {
                        echo 'selected="selected"';
                    };
                    ?>>日峰值</option>
                </select>
                </div>
                <div id="search_month_div" style="padding-left:20px;width:150px; height:20px;float:left;<?php if($tongjitype == 'month'){ ?>display:none; <?php } ?>" ><span>月份:</span>
                <select id="search_month" name="search_month"  onchange="changeSelectMonth();">
                    <?php
                    for ($i = 1; $i <= 12; $i++) {
                        if ($i == $search_month) {
                            echo "<option value='$i' selected='selected'>" . $i . "月</option>";
                        } else {
                            echo "<option value='$i'>" . $i . "月</option>";
                        }
                    }
                    ?>
                </select>
                </div>


                <input type="button" value="搜索" onClick="onCheckSubmit();"/>
            </div> 
        </form>
        </div><br>
	<!---看有多少个图形然后循环动态创建容器div-->
	
	
	<?php 
	   for($i=0;$i<count($return_list);$i++){
	      echo '<div id="maintop'.$i.'" style="height: 350px; border: 1px solid #ccc;width:500px;float: left; text-align: left;margin: 5px 3px 0px 0px;"></div>';
	   }
	
	?>
	
	<!--加载script-->
    <script type="text/javascript">
        // Step:3 为模块加载器配置echarts的路径，从当前页面链接到echarts.js，定义所需图表路径
        require.config({
            paths : {
            echarts:'./echarts/doc/example/www/js'
            }
        });


        <!--获取时间数组-->
        var dataArray=new Array();
        <?php 

         if(in_array($tongjitype,array("month","days"))){
             foreach(array_keys($day_list) as $key=>$day_value){

                if($tongjitype=="month"){               
                     $day_str=  explode("-", $day_value);
                     echo "dataArray.push('".$year."年".intval($day_str[1])."月"."');";
                     
                }elseif($tongjitype=="days"){               
                     $day_str=  explode("-", $day_value);
                     echo "dataArray.push('".$year."年".$search_month."月".intval($day_str[2])."日"."');";
                     
                }
                 

	    }     
            
         }else{
            foreach($time_list as $key=>$each_time_info){
               echo "dataArray.push('".date("Y-m-d",  strtotime($each_time_info['begin']))."到".date("Y-m-d",  strtotime($each_time_info['end']))."');";
            }
            
         }

        ?>


        <!--获取所有的option-->

        <?php 
		
		$grid="grid:{
                    x2:150,//y轴距右侧距离					 
                    y2:130 //x轴距离下侧距离	       
                }";
								
		$tooltip="tooltip : {
					//trigger: 'axis'
				}";
				
		$calculabel='calculable : true';
		
		$xAxis="xAxis : [
					{
						type : 'category',
						boundaryGap : false,
						data : dataArray,
						axisLabel:{
							rotate:-45, //刻度旋转45度角
							textStyle:{
								//color:'red',
								fontSize:6
						   }
						}
					}
				]";
				
	    $yAxis="yAxis : [
					{
						type : 'value',
						axisLabel : {
							formatter: '{value} '
						}
					}
				]";
          $option_index=0;
          foreach($return_list as $host_name=>$each_graph){
            list($host,$graph_name)=explode(":",$host_name);
			
			$title="title : {
					text: '".$graph_name."'
				}"; 
				
			$legend_list=array();
			$item_list=array();
			
			foreach($each_graph as $item_name=>$day_graph_value){
                $legend_list[]="'".$item_name."'";

				$data_list=array();
				foreach($day_graph_value as $key_day=>$max_value){
						$data_list[]="{
							value:".$max_value['value'].",
							tooltip:{
							   formatter: '{b}<br/>{a}:".$max_value['max']."',trigger: 'item'    
							}
						}";
				}
				
				$data=implode(",",$data_list); 
				$item_list[]="{
							name:'".$item_name."',
							type:'line',
							data:[".$data."]
						}";
				
			}

            $len=implode(",",$legend_list);
			
			$legend="legend: {
					data:[$len],
                    orient:'vertical',
                    x:'right'
				}";
				
			$serie=implode(",",$item_list);
            $series="series : [$serie]";	
			 
			 
			$option="{
			         $title,$tooltip,$legend,$grid,$calculabel,$xAxis,$yAxis,$series\n
			 };";

         			
			 echo "\nvar option".$option_index." = ".$option;

 
			 
            $option_index++;
          }

        ?>
		
		
				
		
		
        function topsum(myCharttop,divindex){                   
                   
                       var option=eval("option"+divindex);   
			myCharttop.setOption(option,true);
		};


       // Step:4 动态加载echarts然后在回调函数中开始使用，注意保持按需加载结构定义图表路径
        var ECharts;
        require([ 'echarts',
            'echarts/chart/bar', 
            'echarts/chart/line' ], function(ec) {
            //--- 折柱 ---
            ECharts=ec;
            
            $("div[id^='maintop']").each(function(index,element){
                 myCharttop = ec.init(element);
                 topsum(myCharttop,index);
            });
                
            
        });


       
	</script>	

      </br>
        <div class="bottom" >
            <a href="https://github.com/BillWang139967/zatree" target="_blank">Zatree</a> version 3.0 for Zabbix 3.0.x
        </div>	
        

    </body>
