<?php 
global $zabbix_api_config;

$zabbix_api_config=array(
 'api_url'=>'api_jsonrpc.php',
 'user'=>'ZABBIX_USER',
 'password'=>'ZABBIX_PASS',
 'graph_url'=>'zabbix_chart.php',
 'http_user'=>'ZABBIX_USER',
 'http_password'=>'ZABBIX_PASS'
);



function get_url_config(){

  global $zabbix_api_config;

    if (!empty($zabbix_api_config['http_user'])) {
        $url_http = dirname(dirname('http://' . trim($zabbix_api_config['http_user']) . ':' . trim($zabbix_api_config['http_password']) . '@' . $_SERVER['HTTP_HOST'] . $_SERVER["REQUEST_URI"]));
  
        return array('url'=>$url_http,'user'=>trim($zabbix_api_config['http_user']),'password'=>trim($zabbix_api_config['http_password']));
    } else {
        $url_http = dirname(dirname('http://' . $_SERVER['HTTP_HOST'] . $_SERVER["REQUEST_URI"]));
        return array('url'=>$url_http,'user'=>trim($zabbix_api_config['user']),'password'=>trim($zabbix_api_config['password']));
    }


  


}



?>
