<!DOCTYPE HTML>
<html dir="ltr" lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="Author" content="zatree">
<meta name="keywords" content="zatree">
<meta name="description" content="zatree">
<title>zatree</title>

<link type="text/css" rel="stylesheet" href="static/aqy106Demo.css">
<script type="text/javascript" src="static/jquery.js"></script>
<script type="text/javascript" src="static/aqy106Demo.js"></script>
<script type="text/javascript" src="static/hl-all.js"></script>
<link type="text/css" rel="stylesheet" href="static/style.css">

<script type="text/javascript">
jQuery(function ($) {
     DlHighlight.HELPERS.highlightByName("code", "pre")
});
</script>
<style type="text/css">
.menu{border-left:#ccc 1px solid; height:24px; line-height:24px;}
.menu li{float:left; border:#ccc 1px solid; border-left:0;}
.menu li a{float:left; padding:2px 15px; height:24px; line-height:24px; text-decoration:none; color:#0F79A5; }
.menu li a.cur{color:#fff; font-weight:bold; background-color:#999;}
</style>
</head>

<body>

			<ul class="menu" id="menu">
				<li><a href="/index.php" target="xiaFrame" rel="index.php">首页</a></li>
				<li><a href="/zabbix_tree.php" target="xiaFrame" rel="zabbix.php">HostGraph</a></li>
				<li><a href="peckvalue.php" target="xiaFrame" rel="peckvalue.php">Peckvalue-Table</a></li>
				<li><a href="echart.php" target="xiaFrame" rel="echart.php">Peckvalue-Echart</a></li>
			</ul>
			<script type="text/javascript">
				var urlstr = window.parent.location.href;
				var urlstatus=false;
				$("#menu a").each(function () {
					if ((urlstr + '/').indexOf($(this).attr('rel')) > -1&&$(this).attr('rel')!='') {
						$(this).addClass('cur'); urlstatus = true;
					} else {
						$(this).removeClass('cur');
					}
				});
				if (!urlstatus) {$("#menu a").eq(0).addClass('cur'); }
			</script>

</body>
</html>
