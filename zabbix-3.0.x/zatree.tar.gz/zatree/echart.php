<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>zabbix zatree</title>
</head>

    <frameset rows="30,*" border="1">
      <frame name="header" scrolling="no" src="/zatree/header.php" />
      <frameset cols="220,*" frameborder="1" border="2" framespacing="0" bordercolor="#d0d0d0"`>
		<frame src="/zatree/echart_left.php"  name="leftFrame"  id="leftFrame" title="leftFrame" />
    		<frame src="/zatree/echart_zabbix.php" name="rightFrame" id="rightFrame" title="rightFrame"   />
      </frameset>
    </frameset>

<noframes><body>
</body></noframes>
</html>
